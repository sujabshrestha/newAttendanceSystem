<?php
return [
    'prefix' => [
        'backend' => '',
        'api' => 'api/super-admin',

    ],
    'namespace' => [
        'backend' => 'SuperAdmin\Http\Controllers\Backend',
        'api' => 'SuperAdmin\Http\Controllers\Api',
    ],
    'as' => [
        'backend' => 'backend.',

    ]
];
