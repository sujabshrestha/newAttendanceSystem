<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'prefix' => config('superAdminRoute.prefix.api'),

    'namespace' => config('superAdminRoute.namespace.api'),
], function () {

  

   
});
