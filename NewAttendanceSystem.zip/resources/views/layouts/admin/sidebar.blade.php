<div class="sidebar-wrapper sidebar-theme">

    <nav id="sidebar">
        <div class="shadow-bottom"></div>
        <ul class="list-unstyled menu-categories" id="accordionExample">

            <li class="menu">
                <a href="{{ route('backend.auth.dashboard') }}"
                    {{ strpos(Route::currentRouteName(), 'backend.auth.dashboard') === 0 ? 'data-active=true' : '' }}
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                            class="feather feather-home">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        <span>Dashboard</span>
                    </div>
                </a>
            </li>

            @role(['admin'])

            <li class="menu">
                <a href="{{ route('admin.proposal.index') }}"
                    {{ strpos(Route::currentRouteName(),'admin.proposal.index') === 0 ? 'data-active=true' : '' }}
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Bank Proposals</span>
                    </div>

                </a>

            </li>
            @endrole

            @role(['admin'])
            <li class="menu">
                <a href="#siteVisit" data-toggle="collapse"  class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Site Visit Data</span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="siteVisit" data-parent="#accordionExample">
                    <li class="active">
                        <a href="{{ route('backend.admin.sitevisit.index') }}"> All Site Visit </a>
                    </li>

                </ul>
            </li>
            @endrole



            <li class="menu">
                <a href="#client"
                    {{ strpos(Route::currentRouteName(), 'client') === 0 ? 'data-active=true' : '' }}
                    data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        <span>Manage Clients</span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="feather feather-chevron-right">
                            <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                    </div>
                </a>

                <ul class="collapse submenu list-unstyled {{ strpos(Route::currentRouteName(), 'client') === 0 ? 'show' : '' }}"
                    id="client" data-parent="#accordionExample">
                    <li
                        class=" {{ strpos(Route::currentRouteName(), 'client.index')  === 0 ? 'active' : '' }} ">
                        <a href="{{ route('client.index') }}">Client Lists</a>
                    </li>

                    <li
                        class=" {{ strpos(Route::currentRouteName(), 'client.create') === 0 ? 'active' : '' }} ">
                        <a href="{{ route('client.index') }}">Add New Client </a>
                    </li>

                </ul>
            </li>

            {{-- <li class="menu" style="border-top:solid 1px silver">
                <a href="{{ route('backend.cms.branch.index') }}"
                {{ strpos(Route::currentRouteName(), 'backend.cms.branch') === 0 ? 'data-active=true' : '' }}data-toggle="collapse"  class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Bank Branch</span>
                    </div>

                </a>

            </li> --}}
            @role('admin')
            <li class="menu">
                <a href="{{ route('backend.user.index') }}"
                    {{ strpos(Route::currentRouteName(), 'backend.user') === 0 ? 'data-active=true' : '' }}
                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        <span>Manage Employees</span>
                    </div>

                </a>
            </li>

            <li class="menu">
                <a href="{{ route('backend.siteSetting.create') }}" {{ (request()->routeIs('backend.siteSetting.create')) ? 'data-active=true': '' }} class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span>Site Setting</span>
                    </div>
                </a>
            </li>
            @endrole

            <li class="menu">
                <a href="{{ route('backend.cms.buildingValuationForm  ') }}"
                    {{ strpos(Route::currentRouteName(), 'backend.proposal.index') === 0 ? 'data-active=true' : '' }}
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Building Valuation Form</span>
                    </div>

                </a>

            </li>
            <li class="menu">
                <a href="{{ route('backend.cms.valuationForm') }}"
                    {{ strpos(Route::currentRouteName(), 'backend.proposal.index') === 0 ? 'data-active=true' : '' }}
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Valuation Form</span>
                    </div>

                </a>

            </li>

        </ul>
    </nav>
</div>
